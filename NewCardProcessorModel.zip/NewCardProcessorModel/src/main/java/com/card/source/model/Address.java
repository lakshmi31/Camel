package com.card.source.model;

import java.io.Serializable;

/** This class is for Address of Customer. */
public class Address implements Serializable {

    /** Serialization default ID. */
    private static final long serialVersionUID = 1L;
    /** Customer buildingName. */
    private String buildingName;
    /** Customer Address StreetName. */
    private String streetName;
    /** Customer Address PinCode. */
    private String pincode;
    /** @return the buildingName. */
    public String getBuildingName() {
        return buildingName;
    }
    /** @param buildingName the buildingName to set. */
    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }
    /** @return the streetName. */
    public String getStreetName() {
        return streetName;
    }
    /** @param streetName the streetName to set. */
    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }
    /** @return the pinCode. */
    public String getPincode() {
        return pincode;
    }
    /** @param pincode the pinCode to set. */
    public void setPincode(String pincode) {
        this.pincode = pincode;
    }
    /** @param buildingName Building Name.
     * @param streetName Street Name
     * @param pincode PinCode */
    public Address(String buildingName, String streetName, String pincode) {
        super();
        this.buildingName = buildingName;
        this.streetName = streetName;
        this.pincode = pincode;
    }
    /** Default Constructor of Customer. */
    public Address() {

    }
    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return buildingName + "" + streetName + "" + pincode;
    }

}
