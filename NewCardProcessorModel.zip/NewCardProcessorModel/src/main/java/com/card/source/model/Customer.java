package com.card.source.model;

import java.io.Serializable;
import java.util.Date;

/** POJO class for mapping incoming JSON request for Customer. */
public class Customer implements Serializable {

    /** Serialization default ID. */
    private static final long serialVersionUID = 1L;
    /** Customer FirstName. */
    private String firstName;
    /** Customer LastName. */
    private String lastName;
    /** Customer MobileNumber. */
    private String mobileNumber;
    /** Customer EmailAdderess. */
    private String emailAddress;
    /** Customer DOB. */
    private Date dob;
    /** Customer Address class. */
    private Address address;
    /** Customer Source Identification ID. */
    private String sourceIdentifier;
    /** Customer correlation ID. */
    private String correlationID;
    /** @return the firstName. */
    public String getFirstName() {
        return firstName;
    }
    /** @param firstName the firstName to set. */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    /** @return the lastName. */
    public String getLastName() {
        return lastName;
    }
    /** @param lastName the lastName to set. */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    /** @return the mobileNumber. */
    public String getMobileNumber() {
        return mobileNumber;
    }
    /** @param mobileNumber the mobileNumber to set. */
    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }
    /** @return the emailAddress. */
    public String getEmailAddress() {
        return emailAddress;
    }
    /** @param emailAddress the emailAddress to set. */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
    /** @return the dob. */
    public Date getDob() {
        return dob;
    }
    /** @param dob the dob to set. */
    public void setDob(Date dob) {
        this.dob = dob;
    }
    /** @return the address. */
    public Address getAddress() {
        return address;
    }
    /** @param address the address to set. */
    public void setAddress(Address address) {
        this.address = address;
    }
    /** @return the sourceIdentifier. */
    public String getSourceIdentifier() {
        return sourceIdentifier;
    }
    /** @param sourceIdentifier the sourceIdentifier to set. */
    public void setSourceIdentifier(String sourceIdentifier) {
        this.sourceIdentifier = sourceIdentifier;
    }
    /** @return the correlationID. */
    public String getCorrelationID() {
        return correlationID;
    }
    /** @param correlationID the correlationID to set. */
    public void setCorrelationID(String correlationID) {
        this.correlationID = correlationID;
    }
    /** @param firstName firstName.
     * @param lastName lastName
     * @param mobileNumber mobileNumber
     * @param emailAddress Email
     * @param dob DOB
     * @param address Address class
     * @param sourceIdentifier sourceIdentification ID
     * @param correlationID correlation ID */
    public Customer(String firstName, String lastName, String mobileNumber, String emailAddress, Date dob,
            Address address, String sourceIdentifier, String correlationID) {
        super();
        this.firstName = firstName;
        this.lastName = lastName;
        this.mobileNumber = mobileNumber;
        this.emailAddress = emailAddress;
        this.dob = dob;
        this.address = address;
        this.sourceIdentifier = sourceIdentifier;
        this.correlationID = correlationID;
    }
    /** Default Customer Constructor. */
    public Customer() {
        super();
        // TODO Auto-generated constructor stub
    }
    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Customer [firstName=" + firstName + ", lastName=" + lastName + ", mobileNumber=" + mobileNumber
                + ", emailAddress=" + emailAddress + ", dob=" + dob + ", address=" + address + ", sourceIdentifier="
                + sourceIdentifier + ", correlationID=" + correlationID + "]";
    }

}
