package com.card.application;

import java.util.Arrays;
import java.util.List;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.spring.SpringCamelContext;
import org.dozer.DozerBeanMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import com.card.common.ReadSourceDestinationXML;
import com.card.constant.Constants;
import com.card.dozer.DozerMapping;
import com.card.router.Router;

/** @author ldudhbha */

@Configuration
@EnableAutoConfiguration
@ComponentScan
public class Application {
    /** Main Method.
     * @param args string array.
     * @throws Exception exception thrown. */
    public static void main(String[] args) throws Exception {
        SpringApplication.run(Application.class, args);
    }

    /** @param applicationContext applicationContext
     * @return camelContext context
     * @throws Exception thrown */
    @Bean
    public SpringCamelContext camelContext(ApplicationContext applicationContext) throws Exception {
        SpringCamelContext camelContext = new SpringCamelContext(applicationContext);
        camelContext.addRoutes(routeBuilder());
        return camelContext;
    }

    /** @return Router */
    @Bean
    public RouteBuilder routeBuilder() {
        return new Router();
    }

    /** @return readSourceDestinationXML */
    @Bean
    ReadSourceDestinationXML readSourceDestinationXML() {
        return new ReadSourceDestinationXML();
    }

    /** @return dozerBean */
    @Bean(name = "org.dozer.Mapper")
    public DozerBeanMapper dozerBean() {
        List<String> mappingFiles = Arrays.asList(Constants.DOZER_MAPPING_FILE);
        DozerBeanMapper dozerBean = new DozerBeanMapper();
        dozerBean.setMappingFiles(mappingFiles);
        return dozerBean;
    }
    /** @return DozerMapping */
    @Bean
    DozerMapping dozerMapping() {
        return new DozerMapping();
    }
}