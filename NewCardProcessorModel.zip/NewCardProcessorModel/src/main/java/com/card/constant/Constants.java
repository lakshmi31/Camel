/**
 * @author ldudhbha
 */
package com.card.constant;

/**
 * @author ldudhbha
 */
public final class Constants {
    /** Default private. */
    private Constants() {
    }

    /** Represents timer URL. */
    public static final String TIMER = "timer://event?fixedRate=true&period=30s";
    /** Represents source URL to consume message. */
    public static final String SOURCE_URL_TO_CONSUME = "http://localhost:5223/consumer/getMessage";
    /** Represents source URL to produce message. */
    public static final String SOURCE_URL_TO_PRODUCE = "jms:queue:OUTPUT";
    /** Represents destination TCP URL. */
    public static final String DEST_URL_TCP = "mina2:tcp://localhost:25000?sync=false&textline=true";
    /** Represents destination JMS URL. */
    public static final String DESTINATION_URL_JMS = "jms:queue:IN?jmsMessageType=Text";
    /** Represents source destination file name. */
    public static final String DEST_URL_PRODUCE = "jms:queue:OUT?jmsMessageType=Text";
    /** Represents destination name TCP. */
    public static final String DESTINATION_NAME_TCP = "TCP";
    /** Represents destination name JMS. */
    public static final String DESTINATION_NAME_JMS = "jms";
    /** Represents mapping file name. */
    public static final String DOZER_MAPPING_FILE = "mapping.xml";
    /** Represents source destination file element tag name. */
    public static final String ELEMENT_TAG_NAME = "Transaction";
    /** Represents source destination file element tag name. */
    public static final String ELEMENT_TAG_NAME_PROTOCOL = "protocol";
    /** Represents source destination file element tag name. */
    public static final String ELEMENT_TAG_NAME_PORT = "port";
    /** Represents source destination file element tag name. */
    public static final String ELEMENT_TAG_NAME_DESTIP = "destinationIP";
    /** Represents source destination file element tag name. */
    public static final String ELEMENT_TAG_NAME_SOURCE = "source";
    /** Represents source destination file name. */
    public static final String SOURCE_DESTINATION_FILE_NAME = "source-destination.xml";

}
