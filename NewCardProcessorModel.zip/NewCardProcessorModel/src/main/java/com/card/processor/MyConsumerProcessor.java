package com.card.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import com.card.common.ReadSourceDestinationXML;
import com.card.destination.model.CustomerDestination;
import com.card.dozer.DozerMapping;
import com.card.source.model.Customer;

/** Consumer Processor class to process on request.*/
@Component
public class MyConsumerProcessor implements Processor {
    /** ReadSourceDestinationXML initialization. */
    private ReadSourceDestinationXML destinationXML = new ReadSourceDestinationXML();
    /** Logger. */
    private static final Logger LOG = LoggerFactory.getLogger(MyConsumerProcessor.class);
    /** dozerMapping initialization. */
    private DozerMapping dozerMapping = new DozerMapping();
    /** Method returns the destination customer object.
     * @param exchange message in exchange
     * @throws Exception exception thrown */
    public void process(Exchange exchange) throws Exception {

        LOG.info("Inside Processor:" + exchange.getIn().getBody());
        Customer customerSource = (Customer) exchange.getIn().getBody();
        CustomerDestination customerDestination = dozerMapping.mappedObject(customerSource);
        LOG.info("Sending exchange is:" + customerDestination.toString());
        String headerValue = destinationXML.readXML(customerSource);
        LOG.info("Header Value as URL is:" + headerValue);
        exchange.getOut().setHeader("urlDynamic", headerValue);
        exchange.getOut().setBody(customerDestination.toString() + "\r\n");
    }

}
